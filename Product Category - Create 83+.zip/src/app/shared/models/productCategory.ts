export class ProductCategory {
  // Fill your code here
  id: number;
  category: string;
  isVisible: boolean;
  imageURL: string;
  description: string;
}
